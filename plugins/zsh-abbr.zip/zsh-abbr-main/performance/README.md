## Performance

Requires [zsh-bench](https://github.com/romkatv/zsh-bench).

Run with

```shell
zsh-bench --isolation docker --config-dir ./performance -- not-installed fresh-install zero-abbreviations ten-abbreviations one-hundred-abbreviations
```

Data is at <https://oletsdev.notion.site/oletsdev/zsh-abbr-f2f3a1de08f14c8f8686ece171175400>.
