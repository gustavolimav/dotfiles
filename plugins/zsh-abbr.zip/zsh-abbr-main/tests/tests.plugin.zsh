. ${0:A:h}/tests.zsh
