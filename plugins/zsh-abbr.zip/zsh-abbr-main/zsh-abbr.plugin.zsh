fpath+=${0:A:h}/completions
source ${0:A:h}/zsh-abbr.zsh
